// Reference business-operation layer, NOT a complete MFA implementation.
// Adapt imports/entrypoint to the app. The real verifier from steps 2-5 is required.
import { createClientFromRequest } from 'npm:@base44/sdk';
import { requireAdminMfa } from '../../shared/adminMfa.ts';

export default async function (req: Request): Promise<Response> {
  const headers = { 'Cache-Control': 'no-store' };
  if (req.method !== 'POST') return Response.json({ error: 'POST required' }, { status: 405, headers });
  try {
    const sdk = createClientFromRequest(req);
    const identity = await sdk.auth.me();
    // Verify before consuming the body. Helper must clone it or read a header.
    await requireAdminMfa(req, identity, sdk.asServiceRole.entities);
    const body = await req.json();
    if (body?.action === 'list') {
      const rows = await sdk.asServiceRole.entities.AdminNote.list('-created_date', 20);
      return Response.json({ notes: rows.map(({ id, title, body }) => ({ id, title, body })) }, { headers });
    }
    if (body?.action !== 'create') return Response.json({ error: 'Unsupported action' }, { status: 400, headers });
    if (typeof body.title !== 'string' || !body.title.trim() || body.title.length > 120 ||
        typeof body.body !== 'string' || body.body.length > 2000) {
      return Response.json({ error: 'A title up to 120 and body up to 2000 characters are required' }, { status: 400, headers });
    }
    const note = await sdk.asServiceRole.entities.AdminNote.create({ title: body.title.trim(), body: body.body });
    return Response.json({ note: { id: note.id, title: note.title, body: note.body } }, { status: 201, headers });
  } catch (error) {
    const value = Number(error?.status || error?.response?.status);
    const status = [400, 401, 403, 409, 428, 429].includes(value) ? value : 503;
    return Response.json({ error: 'The note request could not be authorised or completed' }, { status, headers });
  }
}
