# Base44 MFA Builder pack — v1.0, 13 September 2026

Start at https://edwardsapps.co.uk/base44-mfa-guide.html.
This archive is a specification and worked business-operation example, not an installable security product.

- prompts.md: paste one prompt at a time and check the result.
- acceptance.csv: blank evidence worksheet; nothing is pre-marked passed.
- AdminNote.jsonc: the complete pilot entity schema.
- adminNotes-entry.reference.ts: bounded list/create handler; requires the REAL shared verifier produced and tested in steps 2-5. Adapt SDK version, import path and entrypoint to your app. No verifier, UI or recovery implementation is bundled.

The archive has been checked for structure and the reference handler tested with synthetic stubs. That does not test a generated MFA system or Base44 deployment. Do not use a permissive verifier stub outside tests. No production credentials are included. Do not install blindly or replace an existing working MFA setup.
